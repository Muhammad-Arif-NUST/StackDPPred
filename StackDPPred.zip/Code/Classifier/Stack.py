#from sklearn.linear_model import LogisticRegression
import pandas as pd
from sklearn.ensemble import StackingClassifier
from sklearn.linear_model import LogisticRegression
from xgboost import XGBClassifier
from sklearn.ensemble import RandomForestClassifier
from catboost import CatBoostClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix, accuracy_score, classification_report


df_clean = pd.read_csv("pca160.csv")
print(df_clean.shape)
#display (df_clean.head(-5))


X = df_clean.drop(["Class"], axis=1)
y = df_clean["Class"]

X_train, X_test, y_train, y_test = train_test_split(X, y, stratify=y, test_size=0.20, random_state=42)
#train, test = train_test_split(df3,  test_size=0.17,  random_state=42)
print(X_train.shape, y_train.shape)
print(X_test.shape, y_test.shape)



estimators = [('CB' , CatBoostClassifier(iterations=1000,depth=4,learning_rate=0.1,verbose=False,random_seed=42)),
              ('XGB', XGBClassifier()),
              ('DT' , DecisionTreeClassifier(random_state=42)),
              # ('GNB',GaussianNB()),
              # ('LDA', LinearDiscriminantAnalysis()),
              # ('MLP',MLPClassifier(random_state=42, max_iter=300)),
             ]
clf = StackingClassifier( estimators=estimators, 
                          #final_estimator=CatBoostClassifier(learning_rate=0.1, loss_function='MultiClass',verbose=False,random_seed=42))
                          final_estimator=MLPClassifier(random_state=42, max_iter=300))

clf.fit(X_train, y_train)

y_pred_train = clf.predict(X_train)
y_prob_train = clf.predict_proba(X_train)[:,1]

y_pred = clf.predict(X_test)
y_prob = clf.predict_proba(X_test)[:,1]

print('Classification report for test:\n',classification_report(y_test,y_pred))