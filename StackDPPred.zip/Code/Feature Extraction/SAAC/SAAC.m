function [PpseAA]=split_AA(x)
len=size(x,2);
AT=x(1:15);
BT=x(16:len-15);
CT=x(len-15:len);


Frequency1=AminoAcidFrequency(AT);
Frequency2=AminoAcidFrequency(BT);
Frequency3=AminoAcidFrequency(CT);

% lemda=HPHO_HPHL_lemda(x,tiers);
%Also check whether the training and test data is loaded again

PpseAA=[Frequency1 Frequency2 Frequency3];

return